// Quick updates: when the app opens, check for newer game files. When one is downloaded,
// pop up a card offering to restart now. "Later" applies it the next time the app opens.
// Does nothing in a web browser.
(function () {
  var st = function (m) { window.HF_UPD_STATUS = m; };
  st('Not checked yet.');
  var C = window.Capacitor;
  if (!C || !C.isNativePlatform || !C.isNativePlatform()) return st('Updates only run in the iPhone app.');
  var U = C.Plugins && C.Plugins.CapacitorUpdater;
  if (!U) return st('The updater isn\'t installed in this build.');
  // Tell the updater this version started fine (otherwise it rolls back to the last good one).
  U.notifyAppReady();
  var FEED = 'https://raw.githubusercontent.com/davids26640/handy-fix-updates/main/update.json';
  var mine = window.HANDYFIX_VERSION || { id: 'dev', time: 0 };
  var asked = {};

  function card(bundleId, m) {
    if (asked[m.version] || document.getElementById('hfUpd')) return;
    asked[m.version] = true;
    var d = document.createElement('div');
    d.id = 'hfUpd';
    d.style.cssText = 'position:fixed;inset:0;z-index:1000;background:rgba(6,10,24,.62);-webkit-backdrop-filter:blur(3px);backdrop-filter:blur(3px);display:flex;align-items:flex-end;justify-content:center;font-family:Nunito,system-ui,sans-serif';
    var btn = 'display:block;width:100%;border:0;border-radius:16px;padding:15px;font:800 17px Nunito,system-ui,sans-serif;margin-top:9px';
    d.innerHTML =
      '<div style="background:#fff;color:#1c2647;width:100%;max-width:470px;border-radius:26px 26px 0 0;padding:22px 18px calc(18px + env(safe-area-inset-bottom));box-shadow:0 -10px 40px rgba(0,0,0,.35)">' +
      '<div style="font:700 24px Fredoka,Nunito,system-ui,sans-serif;margin-bottom:6px">🎉 Update ready</div>' +
      '<p style="margin:0 0 6px;color:#4a5578;font-size:15.5px;line-height:1.45">A new version of Handy Fix just downloaded' +
      (m.note ? ': <b style="color:#1c2647">' + String(m.note).replace(/[<>&]/g, '').replace(/[.!]?$/, '.') + '</b>' : '.') +
      ' Restart to get it. Your money, gear and progress are saved. A job you\'re in the middle of will start over.</p>' +
      '<button id="hfNow" style="' + btn + ';color:#fff;background:linear-gradient(180deg,#38cc76,#17914a);box-shadow:0 6px 16px rgba(23,145,74,.35)">Restart now</button>' +
      '<button id="hfLater" style="' + btn + ';color:#1f2a4d;background:#eef2fb">Later</button></div>';
    document.body.appendChild(d);
    document.getElementById('hfNow').onclick = function () {
      d.querySelector('#hfNow').textContent = 'Restarting…';
      try { localStorage.setItem('hf_running', '0'); } catch (e) {}
      U.set({ id: bundleId }).catch(function () { location.reload(); });
    };
    document.getElementById('hfLater').onclick = function () { d.remove(); };
  }

  function check() {
    st('Checking for updates…');
    fetch(FEED + '?t=' + Date.now(), { cache: 'no-store' })
      .then(function (r) { if (!r.ok) st('Update check failed: the server answered ' + r.status + '.'); return r.ok ? r.json() : null; })
      .then(function (m) {
        if (!m || !m.url || !m.version) return;
        if (m.version === mine.id || !(m.time > mine.time)) return st('Up to date (newest is ' + m.version + ').');        // already running it, or it's older
        st('Downloading ' + m.version + '…');
        var have = localStorage.getItem('hf_next');
        var haveId = localStorage.getItem('hf_next_id');
        if (have === m.version && haveId) { st(m.version + ' downloaded. Restart the app to use it.'); return card(haveId, m); }          // downloaded earlier, still waiting
        if (!m.checksum) return st('Update ' + m.version + ' has no checksum. Run the Quick update again.');
        return U.download({ url: m.url, version: m.version, checksum: m.checksum }).then(function (b) {
          localStorage.setItem('hf_next', m.version);
          localStorage.setItem('hf_next_id', b.id);
          st(m.version + ' downloaded. Restart the app to use it.');
          return U.next({ id: b.id }).then(function () { card(b.id, m); }); // "Later" = used next launch
        });
      })
      .catch(function (e) { st('Update failed: ' + ((e && (e.message || e.code)) || String(e))); });
  }
  window.HF_CHECK_UPDATE = check;
  check();
  document.addEventListener('visibilitychange', function () { if (!document.hidden) check(); });
})();
