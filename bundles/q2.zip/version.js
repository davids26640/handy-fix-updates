window.HANDYFIX_VERSION = { id: 'q2', time: 1794844677 };
