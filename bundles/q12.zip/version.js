window.HANDYFIX_VERSION = { id: 'q12', time: 1795633114 };
