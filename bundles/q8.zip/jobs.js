// =====================================================================
//  HANDY FIX: YOUR CUSTOM JOBS
//  Add jobs here, commit, and they show up in the game.
//  Full list of kinds and fault names: see JOBS.md in the repo.
//
//  Each job is one { ... } block in the list below. Only "kind" is
//  required. Everything else is optional:
//
//    kind        what type of job (hvac, appl, drain, leak, burst, sump,
//                install, roughin, heater, toilet, electric, tstat, finst, cinst)
//    difficulty  1 (easy) to 10 (hard). Default 5.
//    faults      what's broken, e.g. ['igniter', 'filter']
//                Leave it out and the game picks faults for you.
//    customer    ['👵', 'Mrs. Rivera']  (emoji, name)
//    title       'No heat on Maple St'
//    brief       what the customer says, in quotes
//    pay         dollars, e.g. 150. Leave it out to let the game price it.
//    position    job number to insert at (e.g. 5). Leave it out to add
//                it to the end. Adding to the end keeps players' progress.
//
//  Extra options for some kinds:
//    hvac:    mode: 'heat' or 'cool', layout: 'basement', 'side' or 'attic',
//             condensatePump: true
//    appl:    appliance: 'washer', 'dryer' or 'fridge', lidLock: true
//    drain:   drainCleaner: true (customer poured chemicals in)
//    install: install: 'faucet', 'disposal' or 'dishwasher'
//    electric: building: 'house', 'apt', 'rest', 'office', 'farm' or 'shop'
// =====================================================================

window.HANDYFIX_JOBS = [

  // Example (remove the // at the start of each line to turn it on):
  // {
  //   kind: 'hvac',
  //   mode: 'heat',
  //   difficulty: 4,
  //   faults: ['igniter', 'filter'],
  //   customer: ['👨🏻', 'Mr. Smith'],
  //   title: 'No heat on Elm St',
  //   brief: '"The furnace clicks and hums, but it never lights."',
  //   layout: 'attic',
  // },

];
