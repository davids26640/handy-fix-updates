window.HANDYFIX_VERSION = { id: 'q8', time: 1795615682 };
