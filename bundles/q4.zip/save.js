// Keeps a second copy of your progress in the iPhone's own app storage (Capacitor Preferences).
// iOS can clear a web view's storage (for example while a quick update swaps files in),
// but app storage survives updates. If the web copy goes missing, it's restored from here.
// Does nothing in a web browser.
(function () {
  var C = window.Capacitor;
  if (!C || !C.isNativePlatform || !C.isNativePlatform()) return;
  var P = C.Plugins && C.Plugins.Preferences;
  if (!P) return;
  var KEYS = ['handyfix_build'];
  var ls = window.localStorage;
  var origSet = ls.setItem.bind(ls);
  var atStart = {};
  KEYS.forEach(function (k) { atStart[k] = ls.getItem(k); });
  var ready = false;
  var pending = {};

  function toNative(k, v) {
    if (!ready) { pending[k] = v; return; }
    P.set({ key: k, value: String(v) }).catch(function () {});
  }

  // Mirror every save into app storage.
  Storage.prototype.setItem = function (k, v) {
    origSet.call(this, k, v);
    if (this === ls && KEYS.indexOf(k) >= 0) toNative(k, v);
  };

  // On launch: if the web copy is missing but app storage has one, put it back and reload.
  Promise.all(KEYS.map(function (k) {
    return P.get({ key: k }).then(function (r) { return { k: k, v: r && r.value }; });
  })).then(function (res) {
    var restored = false;
    res.forEach(function (x) {
      if (x.v && !atStart[x.k]) { origSet(x.k, x.v); restored = true; }
    });
    if (restored) { location.reload(); return; }
    ready = true;
    KEYS.forEach(function (k) {
      var v = k in pending ? pending[k] : ls.getItem(k);
      if (v != null) toNative(k, v);
    });
  }).catch(function () { ready = true; });

  // Save once more whenever the app goes to the background.
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden || !ready) return;
    KEYS.forEach(function (k) { var v = ls.getItem(k); if (v != null) toNative(k, v); });
  });
})();
