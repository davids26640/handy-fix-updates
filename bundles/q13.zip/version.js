window.HANDYFIX_VERSION = { id: 'q13', time: 1795639769 };
