window.HANDYFIX_VERSION = { id: 'q1', time: 1794839508 };
