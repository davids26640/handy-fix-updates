// Quick updates: when the app opens, check for newer game files and switch to them
// the next time the app is reopened. Does nothing in a web browser.
(function () {
  var C = window.Capacitor;
  if (!C || !C.isNativePlatform || !C.isNativePlatform()) return;
  var U = C.Plugins && C.Plugins.CapacitorUpdater;
  if (!U) return;
  // Tell the updater this version started fine (otherwise it rolls back to the last good one).
  U.notifyAppReady();
  var FEED = 'https://raw.githubusercontent.com/davids26640/handy-fix-updates/main/update.json';
  var mine = window.HANDYFIX_VERSION || { id: 'dev', time: 0 };
  function check() {
    fetch(FEED + '?t=' + Date.now(), { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (m) {
        if (!m || !m.url || !m.version) return;
        if (m.version === mine.id || !(m.time > mine.time)) return;      // already running it, or it's older
        if (localStorage.getItem('hf_next') === m.version) return;        // already downloaded, waiting for a restart
        return U.download({ url: m.url, version: m.version }).then(function (b) {
          localStorage.setItem('hf_next', m.version);
          return U.next({ id: b.id });                                     // used the next time the app opens
        });
      })
      .catch(function () {});
  }
  check();
  document.addEventListener('visibilitychange', function () { if (!document.hidden) check(); });
})();
